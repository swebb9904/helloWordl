//
//  ViewController.swift
//  DemoApp
//
//  Created by Christina Campbell on 6/2/23.
//

import UIKit

enum Operator {
    case plus, minus, multiply, divide
}

class ViewController: UIViewController {
    @IBOutlet weak var welcomeText: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    var startedTyping = false
    var num1 = 0
    var num2 = 0
    var operations: Operator = .plus
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        welcomeText.text = "Calculator"
    }

    @IBAction func equalTapped(_ sender: UIButton) {
        num2 = Int(resultLabel.text ?? "0")!
        var sum = 0
        switch operations {
        case .plus:
            sum = num1 + num2
        case .minus:
            sum = num1 - num2
        case .multiply:
            sum = num1 * num2
        case .divide:
            sum = num1 / num2
        }
        resultLabel.text = String(sum)
        startedTyping = false
    }
    
    @IBAction func operatorTapped(_ sender: UIButton) {
        num1 = Int(resultLabel.text ?? "0")!
        switch sender.titleLabel?.text {
        case "+":
            operations = .plus
        case "-":
            operations = .minus
        case "/":
            operations = .divide
        case "*":
            operations = .multiply
        default:
            operations = .plus
        }
        startedTyping = false
    }
    
    
    @IBAction func digitTapped(_ sender: UIButton) {
        if let digit = sender.titleLabel?.text {
            if !startedTyping {
                startedTyping = true
                resultLabel.text = digit
            } else {
                resultLabel.text! += digit
            }
        }
    }
}

